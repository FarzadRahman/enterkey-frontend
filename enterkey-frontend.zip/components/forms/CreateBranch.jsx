import React from 'react'

const CreateBranch = () => {
    
//theme imports

  return (
    <div>CreateBranch</div>
  )
}

export default CreateBranch;