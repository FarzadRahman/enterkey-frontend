export const dataset = [
  {
    id: 1,
    year: 1990,
    gain: "5150",
    loss: "699",
  },
  {
    id: 2,
    year: 2007,
    gain: "6000",
    loss: "1125",
  },
  {
    id: 3,
    year: 2007,
    gain: "3868",
    loss: "1385",
  },
  {
    id: 4,
    year: 2004,
    gain: "4640",
    loss: "2704",
  },
  {
    id: 5,
    year: 2003,
    gain: "3020",
    loss: "820",
  },
  {
    id: 6,
    year: 2010,
    gain: "7500",
    loss: "630",
  },
  {
    id: 7,
    year: 2007,
    gain: "7083",
    loss: "3428",
  },
  {
    id: 8,
    year: 2002,
    gain: "9700",
    loss: "3100",
  },
  {
    id: 9,
    year: 1994,
    gain: "6000",
    loss: "3410",
  },
  {
    id: 10,
    year: 1984,
    gain: "4150",
    loss: "1840",
  },
];
