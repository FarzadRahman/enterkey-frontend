//react
import React from "react";

//components
import CreateCustomer from "../../components/forms/CreateCustomer";

const createCustomer = () => {
  return <CreateCustomer />;
};

export default createCustomer;
