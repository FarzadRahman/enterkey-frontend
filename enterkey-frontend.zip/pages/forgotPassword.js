import React from 'react'

function forgotPassword() {
  return (
    <div>forgotPassword</div>
  )
}

export default forgotPassword